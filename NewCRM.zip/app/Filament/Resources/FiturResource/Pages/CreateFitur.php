<?php

namespace App\Filament\Resources\FiturResource\Pages;

use App\Filament\Resources\FiturResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateFitur extends CreateRecord
{
    protected static string $resource = FiturResource::class;
}
