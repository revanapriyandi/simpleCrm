<?php

namespace App\Filament\Resources\KerjaSamaResource\Pages;

use App\Filament\Resources\KerjaSamaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKerjaSama extends CreateRecord
{
    protected static string $resource = KerjaSamaResource::class;
}
